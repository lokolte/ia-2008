#ifndef TSP_IND_H
#define TSP_IND_H

#include <cstddef>
#include "Individual.h"
#include "PermutationChromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;


class TSPMatrix
{
	private:
		int**		matrix;

	public:
		const	size_t	dimension;

		
				TSPMatrix( size_t dim, RandomNr& rn );
			
				~TSPMatrix();
			
			int	at( int x, int y );
};


class TSPIndividual : public Individual
{
	private:
		vector< TSPMatrix* >&	fare;
		size_t			nrOfTowns;
		double			maxDist;
		PermutationChromosome*	chromosome;
			
			
					TSPIndividual( RandomNr& rn, vector< TSPMatrix* >& f, PermutationChromosome* pc );
	
	protected:
		void			subInitRandom();
			
		bool			subMutate();
		
		double			subGetObjective( size_t );
	
	public:
					TSPIndividual( RandomNr& rn, vector< TSPMatrix* >& f );
			
					~TSPIndividual();
			
		Individual*		clone();
			
		double			distance( Distance type, Individual* ind )
						throw ( NilException );
			
		bool			covers( Individual* ind )
						throw ( NilException );
			
		bool			dominates( Individual* ind )
						throw ( NilException );
			
		void			mateWith( Individual* ind, vector< Individual* >& children )
						throw ( NilException );
};

#endif
