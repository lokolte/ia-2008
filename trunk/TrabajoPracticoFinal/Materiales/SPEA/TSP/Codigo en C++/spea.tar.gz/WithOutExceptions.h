/*
	WithOutExeptions.h
	
	In order for the framework NOT to test for exceptions,
	#define NOTIKEAFEXCEPTIONS in this file.
*/
