/*******************************************************************************
	GeneVecChromosome.cpp
		
		last change: 01/07/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See GeneVecChromosome.h
*******************************************************************************/

#include "GeneVecChromosome.h"

#include <cstddef>
#include <vector>
#include "Chromosome.h"
#include "Gene.h"
#include "LinearChromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using namespace std;


GeneVecChromosome::GeneVecChromosome(	RandomNr&		rn,
					vector< Gene* >&	vg )
	: LinearChromosome( rn, vg.size() ), genes( vg )
{
}


GeneVecChromosome::~GeneVecChromosome()
{
	for ( size_t s = 0; s < length; ++s )
	{
		delete genes[ s ];
	}
}


void
GeneVecChromosome::initRandom()
{
	for ( size_t s = 0; s < length; ++s )
	{
		genes[ s ]->initRandom();
	}
}


void
GeneVecChromosome::mutate()
{
	for ( size_t s = 0; s < length; ++s )
	{
		genes[ s ]->mutate();
	}
}


Chromosome*
GeneVecChromosome::clone()
{
	GeneVecChromosome*	gvc;
	vector< Gene* >		vg = vector< Gene* >( length );
	
	for ( size_t s = 0; s < length; ++s )
	{
		vg[ s ] = genes[ s ]->clone();
	}
	gvc = new GeneVecChromosome( randomNr, vg );
	return gvc;
}


void
GeneVecChromosome::setPMutation(	size_t	index,
					double	pm )
	throw ( LimitsException, ProbabilityException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= length )
	{
		throw LimitsException( "from GeneVecChromosome::setPMutation" );
	}
#endif
	
	genes[ index ]->setPMutation( pm );
}


void
GeneVecChromosome::copy(	LinearChromosome*	lc,
				size_t			begin,	// inclusive
				size_t			end )	// exclusive
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( begin > end || end > length )
	{
		throw LimitsException( "from GeneVecChromosome::copy" );
	}
#endif

	GeneVecChromosome*	gvc = dynamic_cast< GeneVecChromosome* >( lc );
		
	for ( size_t s = begin; s < end; ++s )
	{
		delete genes[ s ];
		genes[ s ] = gvc->genes[ s ]->clone();
	}
}


Gene*
GeneVecChromosome::at( size_t index )
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= length )
	{
		throw LimitsException( "from GeneVecChromosome::at" );
	}
#endif

	return genes[ index ];
}
