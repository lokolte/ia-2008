/*******************************************************************************
	LinearChromosome.cpp
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See LinearChromosome.h
*******************************************************************************/

#include "LinearChromosome.h"

#include <cstddef>
#include "Chromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using namespace std;


LinearChromosome::LinearChromosome(	RandomNr&	rn,
					size_t		size )
	: Chromosome( rn ), length( size )
{
}


LinearChromosome::~LinearChromosome()
{
}


size_t
LinearChromosome::size()
{
	return length;
}


void
LinearChromosome::onePointCrossover(	RandomNr&		rn,
					LinearChromosome*	mother,
					LinearChromosome*	father,
					LinearChromosome*	daughter,
					LinearChromosome*	son )
	throw ( NilException, LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( mother == 0 || father == 0 || daughter == 0 || son == 0 )
	{
		throw NilException( "from LinearChromosome::onePointCrossover" );
	}
	
	size_t	length = mother->size();
	
	if ( length != father->size() || length != daughter->size() || length != son->size() )
	{
		throw LimitsException( "from LinearChromosome::onePointCrossover" );
	}
#endif
	
#ifdef NOTIKEAFEXCEPTIONS
	size_t	length = mother->size();
#endif
	size_t	cutPoint = static_cast< size_t >( rn.uniformMinMax( 1, static_cast< int >( length ) ) );
	
	daughter->copy( mother, 0, cutPoint );
	daughter->copy( father, cutPoint, length );
	
	son->copy( father, 0, cutPoint );
	son->copy( mother, cutPoint, length );
}


void
LinearChromosome::twoPointCrossover(	RandomNr&		rn,
					LinearChromosome*	mother,
					LinearChromosome*	father,
					LinearChromosome*	daughter,
					LinearChromosome*	son )
	throw ( NilException, LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( mother == 0 || father == 0 || daughter == 0 || son == 0 )
	{
		throw NilException( "from LinearChromosome::twoPointCrossover" );
	}
	
	size_t	length = mother->size();
	
	if ( length != father->size() || length != daughter->size() || length != son->size() )
	{
		throw LimitsException( "from LinearChromosome::twoPointCrossover" );
	}
#endif
	
#ifdef NOTIKEAFEXCEPTIONS
	size_t	length = mother->size();
#endif
	size_t	cutPoint1,
		cutPoint2;
	int	iLength = static_cast< int >( length );
	
	cutPoint1 = static_cast< size_t >( rn.uniformMinMax( 1, iLength ) );
	do
	{
		cutPoint2 = static_cast< size_t >( rn.uniformMinMax( 1, iLength ) );
	} while ( cutPoint2 == cutPoint1 ); // loops endlessly if length < 3!
	if ( cutPoint1 > cutPoint2 )
	{
		size_t	cp;

		cp = cutPoint1;
		cutPoint1 = cutPoint2;
		cutPoint2 = cp;
	}
	
	daughter->copy( mother, 0, cutPoint1 );
	daughter->copy( father, cutPoint1, cutPoint2 );
	daughter->copy( mother, cutPoint2, length );
	
	son->copy( father, 0, cutPoint1 );
	son->copy( mother, cutPoint1, cutPoint2 );
	son->copy( father, cutPoint2, length );
}
