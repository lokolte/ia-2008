/*******************************************************************************
	Gene.cpp
		
		last change: 01/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See Gene.h
*******************************************************************************/

#include "Gene.h"

#include "RandomNr.h"
#include "TIKEAFExceptions.h"


Gene::Gene(	RandomNr&	rn,
		double		pm )
	throw ( ProbabilityException )
	: randomNr( rn ), pMutation( pm )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( pm < 0 || pm > 1 )
	{
		throw ProbabilityException( "from Gene::Gene" );
	}
#endif
}


Gene::~Gene()
{
}


void
Gene::setPMutation( double pm )
	throw ( ProbabilityException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( pm < 0 || pm > 1 )
	{
		throw ProbabilityException( "from Gene::setPMutation" );
	}
#endif

	pMutation = pm;
}
