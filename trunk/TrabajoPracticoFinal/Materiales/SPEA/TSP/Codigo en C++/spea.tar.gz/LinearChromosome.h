/*******************************************************************************
	LinearChromosome.h
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also Chromosome.h
			LinearChromosome is an abstract subclass. Its tasks:
			1) extend the Chromosome interface,
			2) define the interface for subclasses,
			3) and provide crossover operators.
			
			LinearChromosomes are used to organize genes in a
			linear fashion (e.g., as a string of bits).
*******************************************************************************/

#ifndef LINEAR_CHROMOSOME_H
#define LINEAR_CHROMOSOME_H

#include <cstddef>
#include "Chromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;


class LinearChromosome : public Chromosome
{
	protected:
		const	size_t		length;
	
	public:
			// define the length (size)
					LinearChromosome( RandomNr&, size_t );
				
		virtual			~LinearChromosome();
		
		virtual	void		initRandom()=0;
		
		virtual	void		mutate()=0;
		
			// return a LinearChromosome
		virtual	Chromosome*	clone()=0;
		
			size_t		size();
			
			// reset the mutation probability of a gene
		virtual	void		setPMutation( size_t, double )
						throw ( LimitsException, ProbabilityException )=0;
		
			// copy the alleles in the range
			// (lower bound inclusive, upper bound exclusive)
		virtual	void		copy( LinearChromosome*, size_t, size_t )
						throw ( NilException, LimitsException )=0;

		
		static	void		onePointCrossover( RandomNr&, LinearChromosome*, LinearChromosome*, LinearChromosome*, LinearChromosome* )
						throw ( NilException, LimitsException );
		
		static	void		twoPointCrossover( RandomNr&, LinearChromosome*, LinearChromosome*, LinearChromosome*, LinearChromosome* )
						throw ( NilException, LimitsException );
};

#endif
