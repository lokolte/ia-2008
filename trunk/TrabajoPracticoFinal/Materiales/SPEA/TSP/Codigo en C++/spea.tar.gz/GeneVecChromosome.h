/*******************************************************************************
	GeneVecChromosome.h
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also LinearChromosome.h
			GeneVecChromosome is a concrete subclass of
			LinearChromosome.
			
			GeneVecChromosomes are useful when the different
			decision variables in a chromosome aren't coded
			the same way (e.g., binary and real-valued).
*******************************************************************************/

#ifndef GENE_VEC_CHROMOSOME_H
#define GENE_VEC_CHROMOSOME_H

#include <cstddef>
#include <vector>
#include "Chromosome.h"
#include "Gene.h"
#include "LinearChromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;
using std::vector;


class GeneVecChromosome : public LinearChromosome
{
	private:
			vector< Gene* >	genes;
	
	public:
			// copy the Gene*s
			// the Genes are not cloned!
					GeneVecChromosome( RandomNr&, vector< Gene* >& );
				
		virtual			~GeneVecChromosome();
		
			void		initRandom();
		
			void		mutate();
		
			// return a GeneVecChromosome
			Chromosome*	clone();
			
			void		setPMutation( size_t, double )
						throw ( LimitsException, ProbabilityException );
		
			void		copy( LinearChromosome*, size_t, size_t )
						throw ( LimitsException );
			
			// return a pointer to the Gene
			// at the specified position
			Gene*		at( size_t )
						throw ( LimitsException );
};

#endif
