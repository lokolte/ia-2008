/*******************************************************************************
	Individual.cpp

		last change: 01/06/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See Individual.h
*******************************************************************************/

#include "Individual.h"

#include <cstddef>
#include <vector>
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using namespace std;


Individual::Individual(	RandomNr&	rn,
			size_t		noo )
	: randomNr( rn ), nrOfObjectives( noo ), validObj( noo ), objective( noo )
{
	for ( size_t s = 0; s < nrOfObjectives; ++s )
	{
		validObj[ s ] = false;
	}
}


Individual::~Individual()
{
}


void
Individual::initRandom()
{
	subInitRandom();
	for ( size_t s = 0; s < nrOfObjectives; ++s )
	{
		validObj[ s ] = false;
	}
}


void
Individual::mutate()
{
	if ( subMutate() )
	{
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			validObj[ s ] = false;
		}
	}
}


double
Individual::getObjective( size_t index )
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= nrOfObjectives )
	{
		throw LimitsException( "Individual::getObjective" );
	}
#endif

	if ( !validObj[ index ] )
	{
		objective[ index ] = subGetObjective( index );
		validObj[ index ] = true;
	}
	return objective[ index ];
}


bool
Individual::covers(	bool		bigger,
			Individual*	ind )
{
	if ( bigger )
	{
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			if ( ind->getObjective( s ) > getObjective( s ) )
			{
				return false;
			}
		}
	}
	else
	{
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			if ( ind->getObjective( s ) < getObjective( s ) )
			{
				return false;
			}
		}
	}
	return true;
}


bool
Individual::dominates(	bool		bigger,
			Individual*	ind )
{
	bool	dominated = false;

	if ( bigger )
	{
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			double	igO = ind->getObjective( s ),
				gO = getObjective( s );
			
			if ( igO > gO )
			{
				return false;
			}
			else if ( gO > igO )
			{
				dominated = true;
			}
		}
	}
	else
	{
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			double	igO = ind->getObjective( s ),
				gO = getObjective( s );
			
			if ( igO < gO )
			{
				return false;
			}
			else if ( gO < igO )
			{
				dominated = true;
			}
		}
	}
	return dominated;
}


bool
Individual::equals( Individual* ind )
	throw ( NilException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( ind == 0 )
	{
		throw NilException( "from Individual::equals" );
	}
#endif

	for ( size_t s = 0; s < nrOfObjectives; ++s )
	{
		if ( ind->getObjective( s ) != getObjective( s ) )
		{
			return false;
		}
	}
	return true;
}
