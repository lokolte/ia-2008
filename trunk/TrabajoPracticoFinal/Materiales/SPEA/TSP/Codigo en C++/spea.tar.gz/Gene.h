/*******************************************************************************
	Gene.h
	
		last change: 01/07/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			Gene is an abstract base class. It's primary task is
			to define the interface for its subclasses.
			Methods for setting and getting the allele are
			missing, though!
			
			Genes can be used as building blocks for Chromosomes
			(see GeneVecChromosome for an example), but needn't
			be. Populations operate on Individuals only,
			Individuals typically operate on Chromosomes only.
*******************************************************************************/

#ifndef GENE_H
#define GENE_H

#include "RandomNr.h"
#include "TIKEAFExceptions.h"


class Gene
{
	protected:
			RandomNr&	randomNr;
			double		pMutation;
	
	public:
			// initialize the mutation probability
					Gene( RandomNr&, double )
						throw ( ProbabilityException );
		
		virtual			~Gene();
			
			void		setPMutation( double )
						throw ( ProbabilityException );
				
			// randomly set the allele
		virtual	void		initRandom()=0;
		
		virtual	void		mutate()=0;
		
		virtual	Gene*		clone()=0;
};

#endif
