/*******************************************************************************
	MOEA.cpp
	
		last change: 01/25/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See MOEA.h
*******************************************************************************/

#include "MOEA.h"

#include <cstddef>
#include "RandomNr.h"

using namespace std;


MOEA::MOEA(	RandomNr&	rn,
		size_t		mps )
	: randomNr( rn ), matingPoolSize( mps )
{
}


MOEA::~MOEA()
{
}
