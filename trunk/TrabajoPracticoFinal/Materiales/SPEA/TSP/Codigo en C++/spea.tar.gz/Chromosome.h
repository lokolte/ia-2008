/*******************************************************************************
	Chromosome.h
	
		last change: 01/07/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			Chromosome is an abstract base class. It's primary
			task is to define the interface for its subclasses.
			
			Chromosomes are normally used as building blocks
			for Individuals.
*******************************************************************************/

#ifndef CHROMOSOME_H
#define CHROMOSOME_H

#include <cstddef>
#include "RandomNr.h"

using std::size_t;


class Chromosome
{
	protected:
			RandomNr&	randomNr;
			
	public:
					Chromosome( RandomNr& );
				
		virtual			~Chromosome();
		
			// randomly set all alleles
		virtual	void		initRandom()=0;
		
		virtual	void		mutate()=0;
		
		virtual	Chromosome*	clone()=0;
		
			// return the number of genes in this chromosome
		virtual	size_t		size()=0;
};

#endif
