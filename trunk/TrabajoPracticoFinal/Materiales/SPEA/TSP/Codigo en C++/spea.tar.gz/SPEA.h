/*******************************************************************************
	SPEA.h

		last change: 01/25/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also MOEA.h
			SPEA is a concrete subclass of MOEA.

			SPEA features fitness assignment and selection of
			the Strength Pareto Evolutionary Algorithm.
*******************************************************************************/

#ifndef SPEA_H
#define SPEA_H

#include <cstddef>
#include "MOEA.h"
#include "Population.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"
#include "VecPopulation.h"

using std::size_t;


class SPEA : public MOEA
{
	private:
		const	size_t		maxParetoSize;

			VecPopulation	paretoSet;

	public:
			// define the mating-pool size and
			// the maximum Pareto-set size
					SPEA( RandomNr&, size_t, size_t );
					
			void		select( Population*, Population* )
						throw ( NilException );
			
			void		cloneParetoPoints( Population* )
						throw ( NilException );
};

#endif
