/*******************************************************************************
	Chromosome.cpp
	
		last change: 12/28/1998
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See Chromosome.h
*******************************************************************************/

#include "Chromosome.h"

#include "RandomNr.h"


Chromosome::Chromosome( RandomNr& rn )
	: randomNr( rn )
{
}


Chromosome::~Chromosome()
{
}
