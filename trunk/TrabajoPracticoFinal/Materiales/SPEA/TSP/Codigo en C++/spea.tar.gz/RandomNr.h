/*******************************************************************************
	RandomNr.h
		
		last change: 01/20/1999
						
		version: 0.0.0
			
		design:	Eckart Zitzler
			Paul E. Sevinc
					
		implementation:	Paul E. Sevinc
			
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
					
		description:
			RandomNr is a helper class for pseudo-random number
			generation that doesn't need to be subclassed unless
			one wants to replace the algorithm used or add
			another method.

			Usually, one only instance per optimization problem
			is necessary, and classes or functions that make use
			of random numbers keep a reference to that instance.
*******************************************************************************/

#ifndef RANDOM_NR_H
#define RANDOM_NR_H

#include <cstddef>
#include "TIKEAFExceptions.h"

using std::size_t;


class RandomNr
{
	protected:
			long	z;

	public:
			// use the current time as seed
				RandomNr();

			// use the argument as seed
				RandomNr( long );

			void	setSeed( long );
	
			// return the next uniformly distributed
			// random real in ]0; 1[
		virtual	double	uniform01();

			// return the next uniformly distributed
			// random integer in [Min; Max[
			int	uniformMinMax( int, int )
					throw ( LimitsException );

			// return the next uniformly distributed
			// random integer (size_t) in [0; Max[
			size_t	uniform0Max( size_t )
					throw ( LimitsException );

			// flip an unfair coin (head is up with
			// probability P), return true if head
			// is up and false otherwise
			bool	flipP( double )
					throw ( ProbabilityException );
};

#endif
