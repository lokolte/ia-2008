/*******************************************************************************
	BitStringChromosome.h
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also LinearChromosome.h
			BitStringChromosome is a concrete subclass of
			LinearChromosome.h.
			
			After a BitString has been allocated, one should
			either call initRandom() or define the alleles using
			set(). By default, the mutation probabilities for the
			bits is the inverse of the bit string's length.
*******************************************************************************/

#ifndef BIT_STRING_CHROMOSOME_H
#define BIT_STRING_CHROMOSOME_H

#include <cstddef>
#include <vector>
#include "Chromosome.h"
#include "LinearChromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;
using std::vector;


class BitStringChromosome : public LinearChromosome
{
	private:
			vector< bool >		genes;
			vector< double >	pMutations;
	
	public:
			// define the chromosome length
			// the alleles are not (randomly) set!
						BitStringChromosome( RandomNr&, size_t );
						
			// define the chromosome length and the
			// mutation probability for all genes
			// the alleles are not (randomly) set!
						BitStringChromosome( RandomNr&, size_t, double )
							throw ( ProbabilityException );
				
			void			initRandom();
		
			void			mutate();
		
			// return a BitStringChromosome
			Chromosome*		clone();
			
			void			setPMutation( size_t, double )
							throw ( LimitsException, ProbabilityException );
			
			void			copy( LinearChromosome*, size_t, size_t )
							throw ( NilException, LimitsException );
			
			// set the specified gene to 0 or 1
			void			set( size_t, int )
							throw ( LimitsException );
		
			// get the allele of the specified gene
			int			get( size_t )
							throw ( LimitsException );
};

#endif
