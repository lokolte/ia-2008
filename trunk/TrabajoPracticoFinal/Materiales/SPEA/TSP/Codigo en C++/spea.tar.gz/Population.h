/*******************************************************************************
	Population.h

		last change: 01/26/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			Population is an abstract base class that not only
			defines the interface for its subclasses, but also
			implements many useful operations.
			
			Population subclasses mainly have to deliver the
			actual container. For performance reasons, all
			non-private methods can be overridden, though.
*******************************************************************************/

#ifndef POPULATION_H
#define POPULATION_H

#include <cstddef>
#include <vector>
#include "Individual.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;
using std::vector;


class Population
{
	private:
			void		quicksortUp( int, int );
				
			void		quicksortDown( int, int );
	
	protected:
			RandomNr&	randomNr;

			// exchange the Individuals' position
		virtual	void		switchAt( size_t, size_t )=0;
		
			// get rid of all specified Individuals
			// the indices are in increasing order!
		virtual	void		deleteAt( vector< size_t >& )=0;
		
			// get rid of all Individuals
		virtual	void		deleteAll()=0;
		
			// clone all nondominated Individuals
			// into the other population
		virtual	void		nondominatedPoints( Population* );
		
	public:
					Population( RandomNr& );
		
		virtual			~Population();
			
			// return the number of Individuals
		virtual	size_t		size()=0;

			// sort the Individuals according to their fitness
			// in increasing (true) or decreasing (false) order
		virtual	void		sort( bool );

			// return a pointer to the Individual
			// at the specified position
		virtual	Individual*	at( size_t )
						throw ( LimitsException )=0;
		
			// add an Individual at the end
		virtual	void		pushBack( Individual* )
						throw ( NilException )=0;
		
			// remove the Individual at the end
		virtual	Individual*	popBack()=0;
						
			// remove the Individual at the specified position
			// the new order in the Population is not defined!
		virtual	Individual*	removeAt( size_t )
						throw ( LimitsException )=0;
		
			// tell all Individuals to randomly initialize
		virtual	void		initRandom();

			// tell all Individuals to mutate
		virtual	void		mutate();

			// clone all Individuals and return them
			// in a Population of same dynamic type
		virtual Population*	clone()=0;

			// get rid of all dominated Individuals and
			// duplicates of nondominated Individuals
		virtual	void		deleteCovered();

			// clone all nondominated Individuals into the
			// other Population and call its deleteCovered()
		virtual	void		updateParetoSet( Population* )
						throw ( NilException );
		
			// make random pairs of parents and tell them to mate
			// then put their children into the other Population
		virtual	void		mate2( Population* );
		
			// same as mate2() with mating restrictions
		virtual	void		mate2( Individual::Distance, double, int, Population* )
						throw ( LimitsException );
		
			// reduce the size by average linkage clustering
		virtual	void		aveLinkCluster( Individual::Distance, size_t );
};

#endif
