/*******************************************************************************
	RealValGene.h
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also Gene.h
			RealValGene is a concrete subclass of Gene.
			But it can be subclassed in order to override
			mutate(). (The attributes are declared to be
			protected, not private.)
			
			A RealValGene instance codes real-valued alleles.
			They are stored as doubles. Therefore setAllele()
			expects a double and getAllele() returns a double.
*******************************************************************************/

#ifndef REAL_VAL_GENE_H
#define REAL_VAL_GENE_H

#include "Gene.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"


class RealValGene : public Gene
{
	protected:
		const	double	min,
				max;
	
			double	allele;
			
	public:
			// initialize the mutation probability and
			// the lower and upper allele limit
			// the allele is not (randomly) set!
				RealValGene( RandomNr&, double, double, double )
					throw ( ProbabilityException, LimitsException );
				
			void	initRandom();
			
			// randomly reset the allele
		virtual	void	mutate();
			
			// return a RealValGene
			Gene*	clone();
			
			void	setAllele( double )
					throw ( LimitsException );
			
			double	getAllele();
};

#endif
