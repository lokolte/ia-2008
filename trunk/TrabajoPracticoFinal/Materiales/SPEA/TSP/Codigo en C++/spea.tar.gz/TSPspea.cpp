#include <cstddef>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
#include "RandomNr.h"
#include "SPEA.h"
#include "TIKEAFExceptions.h"
#include "TSPInd.h"
#include "VecPopulation.h"

using namespace std;


int main( int argc, char* argv[] )
{
	// measure the time needed for the optimization...
	long	endTime,
		startTime = static_cast< long >( time( 0 ) );
	
	try
	{
		if ( argc < 8 )
		{
			cerr << "\ntoo few arguments:\n";
			cerr << " nr of towns, nr of objectives, nr of generations, population size, Pareto set size, population seed, run ID";
			cerr << endl;
			
			return 0;
		}

		size_t	nrOfTowns = static_cast< size_t >( atoi( argv[ 1 ] ) ),
			nrOfObjectives = static_cast< size_t >( atoi( argv[ 2 ] ) ),
			nrOfGenerations = static_cast< size_t >( atoi( argv[ 3 ] ) ),
			popSize = static_cast< size_t >( atoi( argv[ 4 ] ) ),
			parSetSize = static_cast< size_t >( atoi( argv[ 5 ] ) );
		long	seed = atol( argv[ 6 ] );
		
		if ( seed == 0 || nrOfTowns == 0 || nrOfObjectives == 0 || popSize == 0 || parSetSize == 0 )
		{
			cerr << "\nsome arguments must not be 0";
			cerr << endl;
			
			return 0;
		}
		
		RandomNr		randomNr( atol( argv[ 1 ] ) ); // seed with nr of towns
		vector< TSPMatrix* >	cost( nrOfObjectives );
		SPEA			spea( randomNr, popSize, parSetSize );
		VecPopulation*		population = new VecPopulation( randomNr, popSize );
		VecPopulation*		nondomSet = new VecPopulation( randomNr, popSize / 5 );
		
		// generate (and print) the matrices
		cout << "Generate matrices..." << endl;
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			TSPMatrix*	matrix = new TSPMatrix( nrOfTowns, randomNr );
			
			cost[ s ] = matrix;
/*
			cout << "\nDistance matrix " << s + 1 << ":\n";
			for ( size_t t = 0; t < nrOfTowns; ++t )
			{
				for ( size_t u = 0; u < nrOfTowns; ++u )
				{
					cout << ' ' << matrix->at( t, u );
				}
				cout << endl;
			}
*/
		}
		cout << "done." << endl;
		
		// initial population
		randomNr.setSeed( seed );
		cout << "Create initial population..." << endl;
		for ( size_t s = 0; s < popSize; ++s )
		{
			population->pushBack( new TSPIndividual( randomNr, cost ) );
		}
		population->initRandom();
		cout << "done." << endl;
		
		// print initial population into file
		string		fileName = "PopT"; fileName += argv[ 1 ]; fileName += "PS"; fileName += argv[ 4 ]; fileName += "."; fileName += argv[ 7 ];
		ofstream	popOut( fileName.c_str() );
		
		cout << "Print initial population out into " << fileName << "..." << endl;
		popOut << "{ {}, { {" << endl;
		if ( popSize > 0 )
		{
			Individual*	ind = population->at( 0 );
			
			popOut << " { " << ind->getObjective( 0 );
			for ( size_t s = 1; s < nrOfObjectives; ++s )
			{
				popOut << ", " << ind->getObjective( s );
			}
			popOut << " }" << endl;
		}
		for ( size_t s = 1; s < popSize; ++s )
		{
			Individual*	ind = population->at( s );

			popOut << ",{ " << ind->getObjective( 0 );
			for ( size_t t = 1; t < nrOfObjectives; ++t )
			{
				popOut << ", " << ind->getObjective( t );
			}
			popOut << " }" << endl;			
		}
		popOut << "}, 0, 0 } }" << endl;
		popOut.close();
		cout << "done." << endl;
		
		cout << "\nEvolve..." << endl;
		population->updateParetoSet( nondomSet );
		for ( size_t s = 0; s < nrOfGenerations; ++s )
		{
			VecPopulation	matingPool( randomNr, popSize );
			
			cout << "Generation " << s + 1 << endl;
			spea.select( population, &matingPool );
			delete population;
			population = new VecPopulation( randomNr, popSize );
			matingPool.mate2( population );
			population->mutate();
			population->updateParetoSet( nondomSet );
		}
		cout << "done.\n" << endl;

		// print nondominated individuals into file
		popSize = nondomSet->size();
		fileName = "SPEAT"; fileName += argv[ 1 ]; fileName += "PS"; fileName += argv[ 4 ]; fileName += "."; fileName += argv[ 7 ];

		ofstream	parOut( fileName.c_str() );
		
		cout << "Print Pareto set out into " << fileName << "..." << endl;
		parOut << "{ {}, { {" << endl;
		if ( popSize > 0 )
		{
			Individual*	ind = nondomSet->at( 0 );
			
			parOut << " { " << ind->getObjective( 0 );
			for ( size_t s = 1; s < nrOfObjectives; ++s )
			{
				parOut << ", " << ind->getObjective( s );
			}
			parOut << " }" << endl;
		}
		for ( size_t s = 1; s < popSize; ++s )
		{
			Individual*	ind = nondomSet->at( s );

			parOut << ",{ " << ind->getObjective( 0 );
			for ( size_t t = 1; t < nrOfObjectives; ++t )
			{
				parOut << ", " << ind->getObjective( t );
			}
			parOut << " }" << endl;			
		}
		parOut << "}, 0, 0 } }" << endl;
		parOut.close();
		cout << "done." << endl;
		
		// clean up
		delete nondomSet;
		delete population;
		for ( size_t s = 0; s < nrOfObjectives; ++s )
		{
			delete cost[ s ];
		}
	}
	catch ( TIKEAFException e )
	{
		cerr << e.message << endl;
	}
	
	// ...and print it out
	endTime = static_cast< long >( time( 0 ) );
	cout << endTime - startTime << " seconds" << endl;
}


/*
g++ RandomNr.cpp Chromosome.cpp PermutationChromosome.cpp Individual.cpp Population.cpp VecPopulation.cpp MOEA.cpp SPEA.cpp TSPInd.cpp TSPspea.cpp
*/
