/*******************************************************************************
	BitGene.h
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also Gene.h
			BitGene is a concrete subclass of Gene.
			
			A BitGene instance codes one of two possible
			alleles. They are stored as bools. Therefore
			setAllele() expects a bool and getAllele() returns
			a bool.
*******************************************************************************/

#ifndef BIT_GENE_H
#define BIT_GENE_H

#include "Gene.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"


class BitGene : public Gene
{
	private:
			bool	allele;
	
	public:
			// initialize the mutation probability
			// the allele is not (randomly) set!
				BitGene( RandomNr&, double )
					throw ( ProbabilityException );
				
			void	initRandom();
			
			// flip the allele
			void	mutate();
			
			// return a BitGene
			Gene*	clone();
			
			void	setAllele( bool );
			
			bool	getAllele();
};

#endif
