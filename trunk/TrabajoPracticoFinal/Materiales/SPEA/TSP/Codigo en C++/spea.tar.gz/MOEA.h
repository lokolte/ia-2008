/*******************************************************************************
	MOEA.h

		last change: 01/25/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			MOEA is an abstract base class that defines the
			interface for the fitness assignment and selection
			steps in a multiobjective evolutionary algorithm.
*******************************************************************************/

#ifndef MOEA_H
#define MOEA_H

#include <cstddef>
#include "Population.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;


class MOEA
{
	protected:
		const	size_t		matingPoolSize;
		
			RandomNr&	randomNr;

	public:
			// define the size of the mating pool
					MOEA( RandomNr&, size_t );
				
		virtual			~MOEA();

			// fill the mating pool by selecting
			// individuals from the population
		virtual	void		select( Population*, Population* )
						throw ( NilException )=0;
};

#endif
