/*******************************************************************************
	TIKEAFExceptions.h
	
	last change: 01/28/1999
		
	version: 0.0.0
		
	design:	Eckart Zitzler
		Paul E. Sevinc
			
	implementation:	Paul E. Sevinc
		
	(c) 1998-1999:	Computer Engineering and Networks Laboratory
			Swiss Federal Institute of Technology Zurich
		
	description:
		This file defines all exceptions used within FEMO,
		the Framework for Evolutionary Multiobjective
		Optimization.
		
		All exceptions are subclasses of TIKEAFException.
		(While in development, FEMO was code-named TIKEAF.)
*******************************************************************************/

#ifndef TIKEAF_EXCEPTIONS_H
#define TIKEAF_EXCEPTIONS_H

#include <string>
#include "WithOutExceptions.h"

using std::string;


// never thrown
class TIKEAFException
{
	public:
		string	message;
		
			TIKEAFException() { message = ""; };
		
			TIKEAFException( string s ) : message( s ) {};	
};


// thrown when a pointer argument is 0
class NilException : public TIKEAFException
{
	public:
		NilException() : TIKEAFException() {};
		
		NilException( string s ) : TIKEAFException( s ) {};
};


// thrown when a probability parameter is not in [0; 1]
class ProbabilityException : public TIKEAFException
{
	public:
		ProbabilityException() : TIKEAFException() {};
		
		ProbabilityException( string s ) : TIKEAFException( s ) {};
};


// thrown when other parameters than a probability are out of well-defined bounds
class LimitsException : public TIKEAFException
{
	public:
		LimitsException() : TIKEAFException() {};
		
		LimitsException( string s ) : TIKEAFException( s ) {};
};

#endif
