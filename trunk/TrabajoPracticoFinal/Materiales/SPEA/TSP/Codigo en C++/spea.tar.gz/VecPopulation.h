/*******************************************************************************
	VecPopulation.h

		last change: 01/11/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also Population.h
			VecPopulation is a concrete subclass of Population
			that overwrites the latter's abstract methods and
			uses a vector<> to manage the Inidvidual*s.
*******************************************************************************/

#ifndef VEC_POPULATION_H
#define VEC_POPULATION_H

#include <cstddef>
#include <vector>
#include "Individual.h"
#include "Population.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;
using std::vector;


class VecPopulation : public Population
{
	private:
			vector< Individual* >	individuals;

	protected:
			void			switchAt( size_t, size_t );

			void			deleteAt( vector< size_t >& );
			
			void			deleteAll();
			
	public:
						VecPopulation( RandomNr& );
						
						VecPopulation( RandomNr&, size_t );

		virtual				~VecPopulation();
			
			size_t			size();
			
			Individual*		at( size_t )
							throw ( LimitsException );
			
			void			pushBack( Individual* )
							throw ( NilException );

			Individual*		popBack();

			Individual*		removeAt( size_t )
							throw ( LimitsException );

			Population*		clone();
};

#endif
