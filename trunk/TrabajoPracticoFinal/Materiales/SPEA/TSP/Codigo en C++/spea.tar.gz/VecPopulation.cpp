/*******************************************************************************
	VecPopulation.cpp

		last change: 01/11/1999

		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See VecPopulation.h
*******************************************************************************/

#include "VecPopulation.h"

#include <cstddef>
#include <vector>
#include "Individual.h"
#include "Population.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using namespace std;


VecPopulation::VecPopulation( RandomNr& rn )
	: Population( rn ), individuals( 0 )
{
}


VecPopulation::VecPopulation(	RandomNr&	rn,
				size_t		estimate )
	: Population( rn ), individuals( 0 )
{
	individuals.reserve( estimate );
}


VecPopulation::~VecPopulation()
{
	size_t	length = individuals.size();

	for ( size_t s = 0; s < length; ++s )
	{
		delete individuals[ s ];
	}
}


void
VecPopulation::switchAt(	size_t	index1,
				size_t	index2 )
{
	Individual*	ind;

	ind = individuals[ index1 ];
	individuals[ index1 ] = individuals[ index2 ];
	individuals[ index2 ] = ind;
}


void
VecPopulation::deleteAt( vector< size_t >& indices )
{
	size_t	lastIndex = individuals.size() - 1;

	for ( size_t s = indices.size(); s > 0; --s ) // s >= 0 loops endlessly!
	{
		size_t	index = indices[ s - 1 ];

		delete individuals[ index ];
		individuals[ index ] = individuals[ lastIndex ];
		individuals.pop_back();
		--lastIndex;
	}
}


void
VecPopulation::deleteAll()
{
	size_t	indSize = individuals.size();
	
	for ( size_t s = 0; s < indSize; ++s )
	{
		delete individuals[ s ];
	}
	individuals.clear();
}


size_t
VecPopulation::size()
{
	return individuals.size();
}


Individual*
VecPopulation::at( size_t index )
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= individuals.size() )
	{
		throw LimitsException( "from VecPopulation::at" );
	}
#endif

	return individuals[ index ];
}


void
VecPopulation::pushBack( Individual* ind )
	throw ( NilException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( ind == 0 )
	{
		throw NilException( "from VecPopulation::pushBack" );
	}
#endif

	individuals.push_back( ind );
}


Individual*
VecPopulation::popBack()
{
	size_t	length = individuals.size();
	
	if ( length > 0 )
	{
		Individual*	ind = individuals[ length - 1 ];
		
		individuals.pop_back();
		return ind;
	}
	else
	{
		return 0;
	}
}


Individual*
VecPopulation::removeAt( size_t index )
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= individuals.size() )
	{
		throw LimitsException( "from VecPopulation::at" );
	}
#endif

	Individual*	ind = individuals[ index ];

	individuals[ index ] = individuals[ individuals.size() - 1 ];
	individuals.pop_back();
	return ind;
}


Population*
VecPopulation::clone()
{
	size_t		length = individuals.size();
	VecPopulation*	vp = new VecPopulation( randomNr, length );
	
	for ( size_t s = 0; s < length; ++s )
	{
		vp->individuals.push_back( individuals[ s ]->clone() );
	}
}
