/*******************************************************************************
	BitStringChromosome.cpp
	
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See BitStringChromosome.h
*******************************************************************************/

#include "BitStringChromosome.h"

#include <cstddef>
#include <vector>
#include "Chromosome.h"
#include "LinearChromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using namespace std;


BitStringChromosome::BitStringChromosome(	RandomNr&	rn,
						size_t		size )
	: LinearChromosome( rn, size ), genes( size ), pMutations( size )
{
	double	pMutation = 1 / static_cast< double >( length );
	
	for ( size_t s = 0; s < length; ++s )
	{
		pMutations[ s ] = pMutation;
	}
}


BitStringChromosome::BitStringChromosome(	RandomNr&	rn,
						size_t		size,
						double		pm )
	throw ( ProbabilityException )
	: LinearChromosome( rn, size ), genes( size ), pMutations( size )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( pm < 0 || pm > 1 )
	{
		throw ProbabilityException( "from BitStringChromosome::BitStringChromosome" );
	}
#endif
	
	for ( size_t s = 0; s < length; ++s )
	{
		pMutations[ s ] = pm;
	}
}


void
BitStringChromosome::initRandom()
{
	for ( size_t s = 0; s < length; ++s )
	{
		genes[ s ] = randomNr.flipP( 0.5 );
	}
}



void
BitStringChromosome::mutate()
{
	for ( size_t s = 0; s < length; ++s )
	{
		if ( randomNr.flipP( pMutations[ s ] ) )
		{
			genes[ s ] = !genes[ s ];
		}
	}
}


Chromosome*
BitStringChromosome::clone()
{
	BitStringChromosome*	bsc = new BitStringChromosome( randomNr, length );
	
	for ( size_t s = 0; s < length; ++s )
	{
		bsc->genes[ s ] = genes[ s ];
		bsc->pMutations[ s ] = pMutations[ s ];
	}
	return bsc;
}


void
BitStringChromosome::setPMutation(	size_t	index,
					double	pm )
	throw ( LimitsException, ProbabilityException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= length )
	{
		throw LimitsException( "from BitStringChromosome::setPMutation" );
	}
	if ( pm < 0 || pm > 1 )
	{
		throw ProbabilityException( "from BitStringChromosome::setPMutation" );
	}
#endif
	
	pMutations[ index ] = pm;
}


void
BitStringChromosome::copy(	LinearChromosome*	lc,
				size_t			begin,	// inclusive
				size_t			end )	// exclusive
	throw ( NilException, LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( lc == 0 )
	{
		throw NilException( "from BitStringChromosome::copy" );
	}
	if ( begin > end || end > length )
	{
		throw LimitsException( "from BitStringChromosome::copy" );
	}
#endif

	BitStringChromosome*	bsc = dynamic_cast< BitStringChromosome* >( lc );
		
	for ( size_t s = begin; s < end; ++s )
	{
		genes[ s ] = bsc->genes[ s ];
		// pMutations[ s ] = bsc->pMutations[ s ];
	}
}


void
BitStringChromosome::set(	size_t	index,
				int	i )
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= length )
	{
		throw LimitsException( "from BitStringChromosome::set" );
	}
#endif
	
	genes[ index ] = static_cast< bool >( i );
}


int
BitStringChromosome::get( size_t index )
	throw ( LimitsException )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( index >= length )
	{
		throw LimitsException( "from BitStringChromosome::get" );
	}
#endif
	
	return static_cast< int >( genes[ index ] );
}
