/*******************************************************************************
	Individual.h

		last change: 02/04/1999
		
		version: 0.0.0

		design:	Eckart Zitzler
			Paul E. Sevinc

		implementation:	Paul E. Sevinc

		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			Individual is an abstract base class that defines
			the interface of solution candidates. The interface
			is tailored for multiobjective applications.
			
			Due to the organization and specification of the
			methods, Individual subclasses don't need to
			calculate the same objective more than once.
*******************************************************************************/

#ifndef INDIVIDUAL_H
#define INDIVIDUAL_H

#include <cstddef>
#include <vector>
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;
using std::vector;


class Individual
{
	private:
			vector< bool >		validObj;
			vector< double >	objective;
	
	public:
		enum Distance { geno, phenoPar, phenoObj };

			double		fitness;

	protected:
		const	size_t		nrOfObjectives;
			
			RandomNr&	randomNr;

			bool		covers( bool, Individual* );

			bool		dominates( bool, Individual* );
			
			// randomly set the chromosomes
		virtual	void		subInitRandom()=0;
			
			// mutate the chromosomes and return
			// true if mutation really took place
		virtual	bool		subMutate()=0;
		
			// get the specified objective value
		virtual	double		subGetObjective( size_t )=0;
	
	public:
			// define the number of objectives
					Individual( RandomNr&, size_t );
				
		virtual			~Individual();
			
			// call subInitRandom() and invalidate validObj
			void		initRandom();

			// call subMutate() and invalidate validObj if
			// necessary (i.e., if subMutate() returns true)
			void		mutate();

		virtual	Individual*	clone()=0;
		
			// call subGetObjective() and validate
			// validObj at the specified index
			double		getObjective( size_t )
						throw ( LimitsException );

			// return the distance of the specified type
			// between this and the other Individual
		virtual	double		distance( Distance, Individual* )
						throw ( NilException )=0;
		
			// return true if the other Individual
			// is covered by this
		virtual	bool		covers( Individual* )
						throw ( NilException )=0;

			// return true if the other Individual
			// is dominated by this
		virtual	bool		dominates( Individual* )
						throw ( NilException )=0;
						
			// return true if the respective objectives
			// of the other Individual are equal
		virtual	bool		equals( Individual* )
						throw ( NilException );
		
			// mate with the other Individual and
			// push the children into the vector
		virtual	void		mateWith( Individual*, vector< Individual* >& )
						throw ( NilException )=0;
};

#endif
