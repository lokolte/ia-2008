/*******************************************************************************
	BitGene.cpp
	
		last change: 01/04/1998
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See BitGene.h
*******************************************************************************/

#include "BitGene.h"

#include "Gene.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"


BitGene::BitGene(	RandomNr&	rn,
			double		pm )
	throw ( ProbabilityException )
	: Gene( rn, pm )
{
}


void
BitGene::initRandom()
{
	allele = randomNr.flipP( 0.5 );
}


void
BitGene::mutate()
{
	allele = !allele;
}


Gene*
BitGene::clone()
{
	BitGene*	bg = new BitGene( randomNr, pMutation );
	
	bg->allele = allele;
	return bg;
}


void
BitGene::setAllele( bool a )
{
	allele = a;
}


bool
BitGene::getAllele()
{
	return allele;
}
