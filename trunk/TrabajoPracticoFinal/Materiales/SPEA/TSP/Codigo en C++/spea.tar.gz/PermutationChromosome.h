/*******************************************************************************
	PermutationChromosome.h
		
		last change: 02/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See also Chromosome.h
			PermutationChromosome is a concrete subclass of
			Chromosome.
			
			mutate() does nothing. PermutationChromosome
			instead features four other methods that perform
			mutations suitable for permutation problems.
*******************************************************************************/

#ifndef PERMUTATION_CHROMOSOME_H
#define PERMUTATION_CHROMOSOME_H

#include <cstddef>
#include <vector>
#include "Chromosome.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"

using std::size_t;
using std::vector;


class PermutationChromosome : public Chromosome
{
	private:
		const	size_t		length;
		
			vector< int >	permutation;
			
			void		permute( size_t, size_t );
	
	public:
			// define the size
			// the alleles are not (randomly) permuted!
					PermutationChromosome( RandomNr&, size_t );
				
			// randomly permute the chromosome
			void		initRandom();

			// do nothing
			void		mutate();
		
			// return a PermutationChromosome
			Chromosome*	clone();
		
			size_t		size();
			
			// get the value at the specified index
			int		get( size_t )
						throw ( LimitsException );
			
			void		inversionMutation();
			
			void		scrambleSublistMutation();
			
			void		moveSequenceMutation();
			
			void		swapMutation();
			
		
		static	void		uniformOrderBasedCrossover( RandomNr&, PermutationChromosome*, PermutationChromosome*, PermutationChromosome*, PermutationChromosome* )
						throw ( NilException, LimitsException );
		
		static	void		edgeRecombinationCrossover( RandomNr&, PermutationChromosome*, PermutationChromosome*, PermutationChromosome* )
						throw ( NilException, LimitsException );
};

#endif
