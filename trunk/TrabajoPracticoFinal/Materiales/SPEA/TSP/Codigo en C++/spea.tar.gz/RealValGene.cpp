/*******************************************************************************
	RealValGene.cpp
	
		last change: 01/04/1999
		
		version: 0.0.0
		
		design:	Eckart Zitzler
			Paul E. Sevinc
			
		implementation:	Paul E. Sevinc
		
		(c) 1998-1999:	Computer Engineering and Networks Laboratory
				Swiss Federal Institute of Technology Zurich
		
		description:
			See RealValGene.h
*******************************************************************************/

#include "RealValGene.h"

#include "Gene.h"
#include "RandomNr.h"
#include "TIKEAFExceptions.h"


RealValGene::RealValGene(	RandomNr&	rn,
				double		pm,
				double		minAllele,
				double		maxAllele )
	throw ( ProbabilityException, LimitsException )
	: Gene( rn, pm ), min( minAllele ), max( maxAllele )
{
#ifndef NOTIKEAFEXCEPTIONS
	if ( min >= max )
	{
		throw LimitsException( "from RealValGene::RealValGene" );
	}
#endif
}


void
RealValGene::initRandom()
{
	allele = min + randomNr.uniform01() * ( max - min );
}


void
RealValGene::mutate()
{
	initRandom();
}


Gene*
RealValGene::clone()
{
	RealValGene*	rvg = new RealValGene( randomNr, pMutation, min, max );
	
	rvg->allele = allele;
	return rvg;
}


void
RealValGene::setAllele( double a )
	throw ( LimitsException )
{
#ifndef NOTIKEAEXCEPTIONS
	if ( a < min || a > max )
	{
		throw LimitsException( "from RealValGene::setAllele" );
	}
#endif

	allele = a;
}


double
RealValGene::getAllele()
{
	return allele;
}
